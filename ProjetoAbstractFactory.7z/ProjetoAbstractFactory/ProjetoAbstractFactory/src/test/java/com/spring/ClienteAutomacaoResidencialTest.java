package com.spring;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

public class ClienteAutomacaoResidencialTest {

    private FabricaAutomacaoResidencial fabricaSmartHome;
    private FabricaAutomacaoResidencial fabricaEcoDevices;

    @BeforeEach
    public void setUp() {
        fabricaSmartHome = new FabricaSmartHome();
        fabricaEcoDevices = new FabricaEcoDevices();
    }

    @Test
    public void testSmartHomeDevices() {
        Luz luz = fabricaSmartHome.criarLuz();
        Termostato termostato = fabricaSmartHome.criarTermostato();

        assertNotNull(luz);
        assertNotNull(termostato);

        luz.ligar();
        luz.desligar();

        termostato.ajustarTemperatura(25);
        assertEquals(25, termostato.obterTemperatura());
    }

    @Test
    public void testEcoDevices() {
        Luz luz = fabricaEcoDevices.criarLuz();
        Termostato termostato = fabricaEcoDevices.criarTermostato();

        assertNotNull(luz);
        assertNotNull(termostato);

        luz.ligar();
        luz.desligar();

        termostato.ajustarTemperatura(18);
        assertEquals(18, termostato.obterTemperatura());
    }
}
