package src;

// Implementação concreta de Luz para SmartHome
public class LuzSmartHome implements Luz {
    @Override
    public void ligar() {
        System.out.println("Luz SmartHome está ligada.");
    }

    @Override
    public void desligar() {
        System.out.println("Luz SmartHome está desligada.");
    }
}