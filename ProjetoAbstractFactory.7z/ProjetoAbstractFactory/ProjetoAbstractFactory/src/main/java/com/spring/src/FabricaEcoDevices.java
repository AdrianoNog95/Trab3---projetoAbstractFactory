package src;

// Fábrica concreta para EcoDevices
public class FabricaEcoDevices implements FabricaAutomacaoResidencial {
    @Override
    public Luz criarLuz() {
        return new LuzEcoDevices();
    }

    @Override
    public Termostato criarTermostato() {
        return new TermostatoEcoDevices();
    }
}