package src;

// Interface para Luz
public interface Luz {
    void ligar();
    void desligar();
}