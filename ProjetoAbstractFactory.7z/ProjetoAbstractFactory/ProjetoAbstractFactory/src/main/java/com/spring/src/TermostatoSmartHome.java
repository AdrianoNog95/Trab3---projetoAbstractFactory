package src;

// Implementação concreta de Termostato para SmartHome
public class TermostatoSmartHome implements Termostato {
    private int temperatura;

    @Override
    public void ajustarTemperatura(int temperatura) {
        this.temperatura = temperatura;
        System.out.println("Termostato SmartHome ajustado para " + temperatura + " graus.");
    }

    @Override
    public int obterTemperatura() {
        return temperatura;
    }
}