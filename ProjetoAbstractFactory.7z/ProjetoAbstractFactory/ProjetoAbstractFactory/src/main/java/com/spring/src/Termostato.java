package src;

// Interface para Termostato
public interface Termostato {
    void ajustarTemperatura(int temperatura);
    int obterTemperatura();
}