package src;

// Interface para a Fábrica Abstrata
public interface FabricaAutomacaoResidencial {
    Luz criarLuz();
    Termostato criarTermostato();
}