package src;

// Implementação concreta de Luz para EcoDevices
public class LuzEcoDevices implements Luz {
    @Override
    public void ligar() {
        System.out.println("Luz EcoDevices está ligada.");
    }

    @Override
    public void desligar() {
        System.out.println("Luz EcoDevices está desligada.");
    }
}