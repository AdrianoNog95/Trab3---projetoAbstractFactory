package src;

// Fábrica concreta para SmartHome
public class FabricaSmartHome implements FabricaAutomacaoResidencial {
    @Override
    public Luz criarLuz() {
        return new LuzSmartHome();
    }

    @Override
    public Termostato criarTermostato() {
        return new TermostatoSmartHome();
    }
}