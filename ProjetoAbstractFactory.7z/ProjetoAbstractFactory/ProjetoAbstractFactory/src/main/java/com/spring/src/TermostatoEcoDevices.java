package src;

public class TermostatoEcoDevices implements Termostato {
    private int temperatura;

    @Override
    public void ajustarTemperatura(int temperatura) {
        this.temperatura = temperatura;
        System.out.println("Termostato EcoDevices ajustado para " + temperatura + " graus.");
    }

    @Override
    public int obterTemperatura() {
        return temperatura;
    }
}