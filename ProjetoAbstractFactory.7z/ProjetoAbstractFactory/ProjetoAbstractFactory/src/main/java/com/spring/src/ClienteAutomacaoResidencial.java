package src;

public class ClienteAutomacaoResidencial {
    private Luz luz;
    private Termostato termostato;

    public ClienteAutomacaoResidencial(FabricaAutomacaoResidencial fabrica) {
        this.luz = fabrica.criarLuz();
        this.termostato = fabrica.criarTermostato();
    }

    public void automatizar() {
        luz.ligar();
        termostato.ajustarTemperatura(22);
        System.out.println("Temperatura Atual: " + termostato.obterTemperatura() + " graus.");
        luz.desligar();
    }

    public static void main(String[] args) {
        // Utilizando a fábrica SmartHome
        FabricaAutomacaoResidencial fabricaSmartHome = new FabricaSmartHome();
        ClienteAutomacaoResidencial clienteSmartHome = new ClienteAutomacaoResidencial(fabricaSmartHome);
        clienteSmartHome.automatizar();

        System.out.println();

        // Utilizando a fábrica EcoDevices
        FabricaAutomacaoResidencial fabricaEcoDevices = new FabricaEcoDevices();
        ClienteAutomacaoResidencial clienteEcoDevices = new ClienteAutomacaoResidencial(fabricaEcoDevices);
        clienteEcoDevices.automatizar();
    }
}